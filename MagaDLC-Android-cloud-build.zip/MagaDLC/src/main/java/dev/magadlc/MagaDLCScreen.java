package dev.magadlc;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class MagaDLCScreen extends Screen {
    private int panelLeft;
    private int panelTop;

    public MagaDLCScreen() {
        super(Component.literal("MagaDLC"));
    }

    @Override
    protected void init() {
        panelLeft = this.width / 2 - 115;
        panelTop = this.height / 2 - 100;
        int x = panelLeft + 12;
        int w = 206;
        int h = 20;
        int y = panelTop + 35;

        addRenderableWidget(Button.builder(toggle("HUD", MagaDLCClient.hudEnabled),
                b -> { MagaDLCClient.hudEnabled = !MagaDLCClient.hudEnabled; refresh(); })
                .bounds(x, y, w, h).build());
        y += 25;
        addRenderableWidget(Button.builder(toggle("Coordinates", MagaDLCClient.showCoords),
                b -> { MagaDLCClient.showCoords = !MagaDLCClient.showCoords; refresh(); })
                .bounds(x, y, w, h).build());
        y += 25;
        addRenderableWidget(Button.builder(toggle("CPS Counter", MagaDLCClient.showCps),
                b -> { MagaDLCClient.showCps = !MagaDLCClient.showCps; refresh(); })
                .bounds(x, y, w, h).build());
        y += 25;
        addRenderableWidget(Button.builder(toggle("Armor Durability", MagaDLCClient.showArmor),
                b -> { MagaDLCClient.showArmor = !MagaDLCClient.showArmor; refresh(); })
                .bounds(x, y, w, h).build());
        y += 25;
        addRenderableWidget(Button.builder(toggle("Keystrokes", MagaDLCClient.showKeystrokes),
                b -> { MagaDLCClient.showKeystrokes = !MagaDLCClient.showKeystrokes; refresh(); })
                .bounds(x, y, w, h).build());
        y += 30;
        addRenderableWidget(Button.builder(Component.literal("Close"),
                b -> onClose()).bounds(x, y, w, h).build());
    }

    private static Component toggle(String label, boolean enabled) {
        return Component.literal(label + ": " + (enabled ? "ON" : "OFF"));
    }

    private void refresh() {
        clearWidgets();
        init();
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        renderBackground(graphics, mouseX, mouseY, delta);
        graphics.fill(panelLeft, panelTop, panelLeft + 230, panelTop + 220, 0xF0181028);
        graphics.fill(panelLeft, panelTop, panelLeft + 230, panelTop + 3, 0xFFB45CFF);
        graphics.drawCenteredString(font, "MagaDLC", width / 2, panelTop + 12, 0xFFE2B8FF);
        super.render(graphics, mouseX, mouseY, delta);
        graphics.drawCenteredString(font, "Right Shift: open menu", width / 2, panelTop + 205, 0xFFB9A8C9);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
