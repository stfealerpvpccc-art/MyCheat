package dev.magadlc;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudElementRegistry;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.Deque;

public final class MagaDLCClient implements ClientModInitializer {
    public static final String MOD_ID = "magadlc";
    public static KeyMapping openMenuKey;
    public static boolean hudEnabled = true;
    public static boolean showCoords = true;
    public static boolean showCps = true;
    public static boolean showArmor = true;
    public static boolean showKeystrokes = true;

    private static final Deque<Long> ATTACKS = new ArrayDeque<>();
    private static int cps;
    private static long lastAttackPress;
    private static boolean prevAttackDown;

    @Override
    public void onInitializeClient() {
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.magadlc.open_menu",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyMapping.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.consumeClick()) {
                if (client.screen == null) client.setScreen(new MagaDLCScreen());
                else if (client.screen instanceof MagaDLCScreen) client.setScreen(null);
            }

            if (client.player == null || client.options == null) return;
            boolean attackDown = client.options.keyAttack.isDown();
            long now = System.currentTimeMillis();
            if (attackDown && !prevAttackDown && now - lastAttackPress > 40) {
                ATTACKS.addLast(now);
                lastAttackPress = now;
            }
            prevAttackDown = attackDown;
            while (!ATTACKS.isEmpty() && now - ATTACKS.peekFirst() > 1000) ATTACKS.removeFirst();
            cps = ATTACKS.size();
        });

        HudElementRegistry.addLast(Identifier.fromNamespaceAndPath(MOD_ID, "main_hud"),
                (graphics, tickCounter) -> renderHud(Minecraft.getInstance(), graphics));
    }

    private static void renderHud(Minecraft mc, GuiGraphics graphics) {
        if (!hudEnabled || mc.player == null || mc.options.hideGui) return;

        int x = 8;
        int y = 8;
        graphics.fill(x - 4, y - 4, x + 142, y + 16, 0xA9181028);
        graphics.fill(x - 4, y - 4, x + 142, y - 2, 0xFFB45CFF);
        graphics.drawString(mc.font, Component.literal("MagaDLC"), x, y, 0xFFE2B8FF, false);
        y += 19;

        if (showCoords) {
            String coords = String.format("XYZ: %d %d %d",
                    (int) mc.player.getX(), (int) mc.player.getY(), (int) mc.player.getZ());
            drawLine(graphics, x, y, coords);
            y += 12;
        }
        if (showCps) {
            drawLine(graphics, x, y, "CPS: " + cps);
            y += 12;
        }
        if (showArmor) {
            int total = 0;
            int count = 0;
            for (var stack : mc.player.getInventory().armor) {
                if (!stack.isEmpty()) {
                    count++;
                    int max = stack.getMaxDamage();
                    total += max <= 0 ? 100 : (int) Math.round(100.0 * (max - stack.getDamageValue()) / max);
                }
            }
            drawLine(graphics, x, y, "Armor: " + (count == 0 ? "--" : (total / count) + "%"));
            y += 12;
        }
        if (showKeystrokes) {
            boolean w = mc.options.keyUp.isDown();
            boolean a = mc.options.keyLeft.isDown();
            boolean s = mc.options.keyDown.isDown();
            boolean d = mc.options.keyRight.isDown();
            boolean jump = mc.options.keyJump.isDown();
            String keys = (w ? "[W]" : " W ") + " " +
                    (a ? "[A]" : " A ") + (s ? "[S]" : " S ") + (d ? "[D]" : " D ") +
                    (jump ? " [SPACE]" : " SPACE ");
            drawLine(graphics, x, y, keys);
        }
    }

    private static void drawLine(GuiGraphics graphics, int x, int y, String text) {
        int width = Math.min(340, Minecraft.getInstance().font.width(text) + 8);
        graphics.fill(x - 4, y - 2, x - 4 + width, y + 10, 0x99181028);
        graphics.drawString(Minecraft.getInstance().font, Component.literal(text), x, y, 0xFFF4E9FF, false);
    }
}
