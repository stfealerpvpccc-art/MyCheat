# MagaDLC — Fabric 1.21.11

Client-side HUD mod project for Minecraft Java Edition 1.21.11.

## Included
- MagaDLC purple/dark HUD title
- Coordinates
- CPS counter
- Average armor durability
- WASD + space indicators
- ClickGUI opened with Right Shift
- Individual ON/OFF toggles

## Requirements
- Java 21
- Minecraft 1.21.11
- Fabric Loader 0.18.1 or newer compatible release
- Fabric API 0.141.1+1.21.11

## Build
Install Java 21 and Gradle 9.x, open a terminal in this folder, then run:

Windows:
    gradle build

Linux/macOS:
    gradle build

The remapped mod jar should appear in `build/libs/`.

## Install
Copy the built `magadlc-1.0.0.jar` from `build/libs/` into the Minecraft instance's `mods` folder alongside Fabric API.

## Controls
- Right Shift — open/close MagaDLC menu

This initial version focuses on HUD and client-side visual settings. It does not include anti-cheat bypass or hidden combat automation.
